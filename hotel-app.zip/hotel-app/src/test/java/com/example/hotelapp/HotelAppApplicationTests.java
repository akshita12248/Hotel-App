package com.example.hotelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
